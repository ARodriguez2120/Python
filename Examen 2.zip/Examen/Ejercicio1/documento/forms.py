from django import forms
from .models import wiki

class FormCreate(forms.ModelForm):
 	class Meta:
 		model=wiki
 		
 		fields=["titulo",
 		"autor",
 		"categoria",
 		"media",
 		"contenido"]


 		label={"titulo": "Titulo",
 		"autor": "Autor",
 		"categoria": "Categoria",
 		"media": "Archivo",
 		"contenido": "Contenido" ,
 		}

 		widgets={
 		"titulo": forms.TextInput(attrs={'class':'form-control'}),
 		"autor": forms.TextInput(attrs={'class':'form-control'}),
 		"categoria": forms.Select(attrs={'class':'form-control'}),
 		}
