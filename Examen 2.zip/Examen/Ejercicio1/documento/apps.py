from django.apps import AppConfig


class DocumentoConfig(AppConfig):
    name = 'documento'
