from django.shortcuts import render
from .forms import FormCreate
from django.views import generic
from .models import wiki,Categoria

# Create your views here.

def index(request):
	
	return render(request,"wikipedia/index.html",{})

class Categorias(generic.ListView):
	template_name="wikipedia/categorias.html"
	model=Categoria



def list_docs(request,id=1):
	queryset1=Categoria.objects.get(id=id)	
	queryset2=wiki.objects.all()
	contex={"documento":queryset1,"documentos":queryset2}
	return render(request,"wikipedia/list_docs.html",contex)

class details(generic.DetailView):
	template_name="wikipedia/details.html"
	model=wiki

class Create(generic.CreateView):
 	template_name="wikipedia/create.html"
 	model=wiki
 	fields=["titulo","autor","categoria","media","contenido"]
 	success_url="/"