from django.contrib import admin
from .models import Categoria,wiki

# Register your models here.

admin.site.register(Categoria)
admin.site.register(wiki)
