from django.contrib import admin
from django.urls import path

from documento import views
app_name="documento"

urlpatterns = [
	path('create/',views.Create.as_view(), name="create_view"),
	path('',views.Categorias.as_view(),name="categorias_view"),
	path('list_docs/<int:id>',views.list_docs,name="list_view"),
	path('details/<int:pk>',views.details.as_view(),name="details_view"),
	
]