from django.shortcuts import render
from .forms import FormCreate
from django.views import generic
from .models import programa,Departamento

# Create your views here.


def index(request):
	context={}

	return render (request, "vistas/index.html", {})

class reg_dep(generic.CreateView):
 	template_name="vistas/nuevo.html"
 	model=Departamento
 	fields=["departamento"]
 	success_url="/"


class Depto(generic.ListView):
	template_name="vistas/departamentos.html"
	model=Departamento


def list(request,id=1):
	set1=Departamento.objects.get(id=id)	
	set2=programa.objects.all()
	context={
	"departamentos":set1,
	"software":set2
	}

	return render(request,"vistas/listado.html",context)



class details(generic.DetailView):
	template_name="vistas/details.html"
	model=programa

class Create(generic.CreateView):
 	template_name="vistas/create.html"
 	model=programa
 	fields=["nombre","funcion","departamento"]
 	success_url="/"