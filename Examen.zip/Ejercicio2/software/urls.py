from django.contrib import admin
from django.urls import path

from software import views
app_name="software"

urlpatterns = [
	


	path('create/',views.Create.as_view(), name="create_view"),
	path('registro/',views.reg_dep.as_view(), name="reg_view"),
	path('',views.Depto.as_view(),name="departamento_view"),
	path('list/<int:id>',views.list,name="list_view"),
	path('details/<int:pk>',views.details.as_view(),name="details_view"),
]