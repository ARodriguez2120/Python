from django.apps import AppConfig


class SoftwareConfig(AppConfig):
    name = 'software'
