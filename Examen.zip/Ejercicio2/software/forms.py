from django import forms
from .models import programa,Departamento

class FormCreate(forms.ModelForm):
 	class Meta:
 		model=programa
 		
 		fields=["nombre",
 		"funcion",
 		"departamento"
 		]


 		label={"nombre": "Nombre  ",
 		"funcion": "Funcion  ",
 		"departamento": "Departamento  "
 		}

 		widgets={
 		"nombre": forms.TextInput(attrs={'class':'form-control'}),
 		"funcion": forms.TextInput(attrs={'class':'form-control'}),
 		"departamento": forms.Select(attrs={'class':'form-control'}),
 		}

class FormCreate1(forms.ModelForm):
 	class Meta:
 		model=Departamento
 		
 		fields=["departamento"
 		]


 		label={"departamento": "Departamento"
 		}

 		widgets={"departamento": forms.Select(attrs={'class':'form-control'}),
 		}
